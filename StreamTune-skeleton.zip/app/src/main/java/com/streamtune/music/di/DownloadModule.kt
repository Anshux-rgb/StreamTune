package com.streamtune.music.di

import android.content.Context
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.offline.DownloadManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.io.File
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import javax.inject.Singleton

/**
 * Everything needed for offline downloads, in one place. The cache lives in
 * app-private storage (`filesDir`), so no storage permission is needed and
 * it's wiped automatically on uninstall.
 */
@Module
@InstallIn(SingletonComponent::class)
object DownloadModule {

    // Caps total downloaded audio at 2GB; oldest-accessed files are evicted
    // first once the cap is hit. Tune to taste.
    private const val MAX_CACHE_BYTES = 2L * 1024 * 1024 * 1024

    @Provides
    @Singleton
    fun provideDatabaseProvider(@ApplicationContext context: Context): StandaloneDatabaseProvider =
        StandaloneDatabaseProvider(context)

    @Provides
    @Singleton
    fun provideDownloadCache(
        @ApplicationContext context: Context,
        databaseProvider: StandaloneDatabaseProvider
    ): Cache {
        val downloadDir = File(context.filesDir, "offline_music")
        return SimpleCache(downloadDir, LeastRecentlyUsedCacheEvictor(MAX_CACHE_BYTES), databaseProvider)
    }

    @Provides
    @Singleton
    fun provideDownloadExecutor(): Executor = Executors.newFixedThreadPool(3)

    /** Owns the actual download queue — enqueue/pause/remove all go through this. */
    @Provides
    @Singleton
    fun provideDownloadManager(
        @ApplicationContext context: Context,
        databaseProvider: StandaloneDatabaseProvider,
        cache: Cache,
        httpDataSourceFactory: DefaultHttpDataSource.Factory,
        executor: Executor
    ): DownloadManager =
        DownloadManager(context, databaseProvider, cache, httpDataSourceFactory, executor).apply {
            maxParallelDownloads = 3
            minRetryCount = 3
        }

    /**
     * What ExoPlayer actually plays through. It checks the download cache
     * first — a downloaded song plays with zero network calls — and falls
     * back to streaming from the network for anything not yet downloaded,
     * silently populating the same cache as a side effect of playing it.
     */
    @Provides
    @Singleton
    fun provideCacheDataSourceFactory(
        cache: Cache,
        httpDataSourceFactory: DefaultHttpDataSource.Factory
    ): CacheDataSource.Factory =
        CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(httpDataSourceFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
}
