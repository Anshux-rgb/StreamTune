package com.streamtune.music

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.DownloadForOffline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.streamtune.music.ui.components.MiniPlayer
import com.streamtune.music.ui.downloads.DownloadsScreen
import com.streamtune.music.ui.favorites.FavoritesScreen
import com.streamtune.music.ui.home.HomeScreen
import com.streamtune.music.ui.player.PlayerScreen
import com.streamtune.music.ui.player.PlayerViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StreamTuneTheme {
                StreamTuneApp()
            }
        }
    }
}

@Composable
private fun StreamTuneTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dynamicColor = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val colorScheme = when {
        dynamicColor -> dynamicDarkColorScheme(context) // dark theme by default, per spec
        else -> darkColorScheme()
    }
    MaterialTheme(colorScheme = colorScheme, content = content)
}

private data class BottomTab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)
private val bottomTabs = listOf(
    BottomTab("home", "Home", Icons.Default.Home),
    BottomTab("favorites", "Favorites", Icons.Default.Favorite),
    BottomTab("downloads", "Downloads", Icons.Default.DownloadForOffline)
)

/** Root Scaffold: bottom nav (Home/Favorites) behind, mini-player floating above it, full player overlaying both when expanded. */
@Composable
private fun StreamTuneApp() {
    val navController = rememberNavController()
    val playerViewModel: PlayerViewModel = hiltViewModel()
    val playbackState by playerViewModel.uiState.collectAsState()
    var isPlayerExpanded by remember { mutableStateOf(false) }

    val onQueueSelected: (List<com.streamtune.music.data.remote.SearchResult>, Int) -> Unit =
        { tracks, startIndex -> playerViewModel.playQueue(tracks, startIndex) }

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination
            NavigationBar {
                bottomTabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute?.hierarchy?.any { it.route == tab.route } == true,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(bottom = innerPadding.calculateBottomPadding())) {
            NavHost(navController = navController, startDestination = "home") {
                composable("home") { HomeScreen(onQueueSelected = onQueueSelected) }
                composable("favorites") { FavoritesScreen(onQueueSelected = onQueueSelected) }
                composable("downloads") { DownloadsScreen(onQueueSelected = onQueueSelected) }
            }

            AnimatedVisibility(
                visible = !isPlayerExpanded && playbackState.currentTitle.isNotBlank(),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
            ) {
                MiniPlayer(
                    state = playbackState,
                    onTogglePlayPause = playerViewModel::togglePlayPause,
                    onSkipNext = playerViewModel::skipNext,
                    onExpand = { isPlayerExpanded = true }
                )
            }
        }
    }

    // Full player overlays the whole Scaffold (including the bottom nav) when expanded.
    AnimatedVisibility(visible = isPlayerExpanded) {
        PlayerScreen(onCollapse = { isPlayerExpanded = false }, viewModel = playerViewModel)
    }
}
