package com.streamtune.music.ui.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.streamtune.music.data.local.FavoriteSongEntity
import com.streamtune.music.data.remote.SearchResult
import com.streamtune.music.data.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavoritesViewModel @Inject constructor(
    private val repository: MusicRepository
) : ViewModel() {

    val favorites: StateFlow<List<FavoriteSongEntity>> = repository.observeFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val downloadedVideoIds: StateFlow<Set<String>> = repository.observeDownloads()
        .map { downloads -> downloads.filter { it.isComplete }.map { it.videoId }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    fun asSearchResults(entities: List<FavoriteSongEntity>): List<SearchResult> =
        entities.map { SearchResult(it.videoId, it.title, it.artist, it.thumbnailUrl) }

    fun removeFavorite(track: SearchResult) {
        viewModelScope.launch { repository.toggleFavorite(track) } // toggling an existing favorite removes it
    }

    fun downloadTrack(track: SearchResult) {
        viewModelScope.launch { repository.downloadTrack(track) }
    }
}
