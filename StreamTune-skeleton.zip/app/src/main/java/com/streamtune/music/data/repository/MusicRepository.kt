package com.streamtune.music.data.repository

import com.streamtune.music.data.download.DownloadRepository
import com.streamtune.music.data.local.FavoriteDao
import com.streamtune.music.data.local.FavoriteSongEntity
import com.streamtune.music.data.local.HistoryDao
import com.streamtune.music.data.local.HistoryEntity
import com.streamtune.music.data.remote.MusicExtractor
import com.streamtune.music.data.remote.SearchResult
import com.streamtune.music.data.remote.StreamInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single entry point the ViewModels talk to. Keeps the "where does this data
 * come from" question (network vs. local DB) out of the UI layer, per Clean
 * Architecture — ViewModels only know about this repository's interface.
 */
@Singleton
class MusicRepository @Inject constructor(
    private val extractor: MusicExtractor,
    private val favoriteDao: FavoriteDao,
    private val historyDao: HistoryDao,
    private val downloadRepository: DownloadRepository
) {
    suspend fun search(query: String): Result<List<SearchResult>> = runCatching {
        extractor.search(query)
    }

    suspend fun getHomeFeed() = runCatching { extractor.getHomeFeed() }

    /**
     * Resolves a playable stream for [track], preferring the on-disk download
     * over the network whenever one is fully complete. This is what makes
     * "play offline with no internet" actually work: a fully downloaded track
     * never touches the network here at all, so there's nothing to time out.
     * See [DownloadRepository]'s class doc for why a stable cache key (not the
     * ephemeral signed URL) is what ties a download to later playback.
     */
    private suspend fun resolveStream(track: SearchResult): StreamInfo? {
        val isDownloaded = withContext(Dispatchers.IO) { downloadRepository.isFullyDownloaded(track.videoId) }
        if (isDownloaded) {
            return StreamInfo(
                videoId = track.videoId,
                streamUrl = "https://offline.streamtune.local/${track.videoId}", // never actually fetched — see doc above
                mimeType = "audio/mp4",
                bitrateKbps = 0
            )
        }
        return runCatching { extractor.getStreamUrl(track.videoId) }.getOrNull()
    }

    /**
     * Resolves the direct audio URL for a track and records it into playback
     * history. Returns null (rather than throwing) on socket/network errors so
     * the caller can show a "couldn't play this track" message instead of
     * crashing the player.
     */
    suspend fun prepareStream(result: SearchResult): StreamInfo? {
        val stream = resolveStream(result) ?: return null
        historyDao.record(
            HistoryEntity(
                videoId = result.videoId,
                title = result.title,
                artist = result.artist,
                thumbnailUrl = result.thumbnailUrl,
                playedAtEpochMs = System.currentTimeMillis()
            )
        )
        return stream
    }

    /**
     * Resolves stream URLs for an entire queue up front, in parallel, so the
     * player can call `MediaController.setMediaItems(list, startIndex, ...)`
     * once instead of stalling on a network round-trip every time the user
     * hits "next". Tracks whose stream fails to resolve are dropped rather
     * than aborting the whole queue — a single dead video shouldn't block
     * everything after it.
     */
    suspend fun prepareQueue(tracks: List<SearchResult>, startIndex: Int = 0): QueuePreparationResult = coroutineScope {
        val resolved = tracks.map { track ->
            async { track to resolveStream(track) }
        }.awaitAll()

        val playable = resolved.mapNotNull { (track, stream) -> stream?.let { track to it } }
        if (playable.isNotEmpty()) {
            val anchor = tracks.getOrNull(startIndex) ?: tracks.first()
            historyDao.record(
                HistoryEntity(
                    videoId = anchor.videoId,
                    title = anchor.title,
                    artist = anchor.artist,
                    thumbnailUrl = anchor.thumbnailUrl,
                    playedAtEpochMs = System.currentTimeMillis()
                )
            )
        }

        // Re-map the caller's requested start index onto the filtered list,
        // in case a track ahead of it got dropped for failing to resolve.
        val originalStartId = tracks.getOrNull(startIndex)?.videoId
        val adjustedStartIndex = playable.indexOfFirst { it.first.videoId == originalStartId }.coerceAtLeast(0)

        QueuePreparationResult(
            items = playable,
            startIndex = adjustedStartIndex,
            droppedCount = tracks.size - playable.size
        )
    }

    fun observeFavorites(): Flow<List<FavoriteSongEntity>> = favoriteDao.observeAll()

    suspend fun isFavorite(videoId: String): Boolean = favoriteDao.isFavorite(videoId)

    suspend fun toggleFavorite(result: SearchResult) {
        if (favoriteDao.isFavorite(result.videoId)) {
            favoriteDao.remove(result.videoId)
        } else {
            favoriteDao.add(
                FavoriteSongEntity(
                    videoId = result.videoId,
                    title = result.title,
                    artist = result.artist,
                    thumbnailUrl = result.thumbnailUrl,
                    addedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
    }

    fun observeHistory(): Flow<List<HistoryEntity>> = historyDao.observeRecent()

    // --- Offline downloads (thin pass-through so ViewModels only need one repository) ---
    fun observeDownloads() = downloadRepository.downloads
    fun isDownloaded(videoId: String): Boolean = downloadRepository.isFullyDownloaded(videoId)
    suspend fun downloadTrack(track: SearchResult): Boolean = downloadRepository.downloadTrack(track)
    fun removeDownload(videoId: String) = downloadRepository.removeDownload(videoId)
}

/** Result of resolving a whole queue: which tracks actually got a playable stream, and where to start. */
data class QueuePreparationResult(
    val items: List<Pair<SearchResult, StreamInfo>>,
    val startIndex: Int,
    val droppedCount: Int
)
