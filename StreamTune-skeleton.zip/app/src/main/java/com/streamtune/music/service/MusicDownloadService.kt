package com.streamtune.music.service

import android.app.Notification
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.scheduler.Scheduler
import com.streamtune.music.R
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Keeps downloads running (and shows a progress notification) independently
 * of any Activity/Compose screen being on top — the same pattern as
 * [PlaybackService], just for writing bytes to disk instead of playing them.
 *
 * Nothing here decides *what* to download; [DownloadRepository] builds the
 * [androidx.media3.exoplayer.offline.DownloadRequest] and hands it to this
 * service via [DownloadService.sendAddDownload].
 */
@AndroidEntryPoint
class MusicDownloadService : DownloadService(
    NOTIFICATION_ID,
    DEFAULT_FOREGROUND_NOTIFICATION_UPDATE_INTERVAL,
    CHANNEL_ID,
    R.string.download_channel_name,
    0
) {
    @Inject
    lateinit var downloadManagerInstance: DownloadManager

    private val notificationHelper: DownloadNotificationHelper by lazy {
        DownloadNotificationHelper(this, CHANNEL_ID)
    }

    override fun getDownloadManager(): DownloadManager = downloadManagerInstance

    // Returning null means downloads pause if the app/service is killed and
    // don't auto-resume on device reboot. Wiring a real Scheduler (e.g.
    // WorkManagerScheduler) plus RECEIVE_BOOT_COMPLETED is the next step if
    // you want "resume interrupted downloads in the background" behavior.
    override fun getScheduler(): Scheduler? = null

    override fun getForegroundNotification(downloads: MutableList<Download>, notMetRequirements: Int): Notification =
        notificationHelper.buildProgressNotification(
            this,
            android.R.drawable.stat_sys_download,
            /* contentIntent = */ null,
            /* message = */ null,
            downloads,
            notMetRequirements
        )

    companion object {
        private const val CHANNEL_ID = "streamtune_downloads"
        private const val NOTIFICATION_ID = 2001
    }
}
