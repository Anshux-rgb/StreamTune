package com.streamtune.music.ui.favorites

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.streamtune.music.data.remote.SearchResult

/**
 * @param onQueueSelected same contract as HomeScreen — (full list, tapped index)
 * so tapping a saved song queues the rest of the favorites list to play after it.
 */
@Composable
fun FavoritesScreen(
    onQueueSelected: (tracks: List<SearchResult>, startIndex: Int) -> Unit,
    viewModel: FavoritesViewModel = hiltViewModel()
) {
    val favorites by viewModel.favorites.collectAsState()
    val downloadedIds by viewModel.downloadedVideoIds.collectAsState()
    val tracks = viewModel.asSearchResults(favorites)

    if (tracks.isEmpty()) {
        EmptyFavorites()
        return
    }

    LazyColumn {
        itemsIndexed(tracks, key = { _, it -> it.videoId }) { index, track ->
            val isDownloaded = track.videoId in downloadedIds
            ListItem(
                headlineContent = { Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingContent = {
                    AsyncImage(
                        model = track.thumbnailUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(48.dp).clip(RoundedCornerShape(6.dp))
                    )
                },
                trailingContent = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (!isDownloaded) viewModel.downloadTrack(track) }, enabled = !isDownloaded) {
                            Icon(
                                imageVector = if (isDownloaded) Icons.Default.DownloadDone else Icons.Default.Download,
                                contentDescription = if (isDownloaded) "Downloaded" else "Download for offline listening",
                                tint = if (isDownloaded) MaterialTheme.colorScheme.primary else LocalContentColor.current
                            )
                        }
                        IconButton(onClick = { viewModel.removeFavorite(track) }) {
                            Icon(Icons.Default.Favorite, contentDescription = "Remove from favorites", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                },
                modifier = Modifier.clickable { onQueueSelected(tracks, index) }
            )
        }
    }
}

@Composable
private fun EmptyFavorites() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.MusicNote,
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "No favorites yet — tap the heart on any track to save it here.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
