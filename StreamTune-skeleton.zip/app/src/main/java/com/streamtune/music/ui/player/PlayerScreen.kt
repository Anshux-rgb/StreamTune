package com.streamtune.music.ui.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import java.util.concurrent.TimeUnit

@Composable
fun PlayerScreen(
    onCollapse: () -> Unit,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var sliderPosition by remember { mutableFloatStateOf(0f) }
    var isUserSeeking by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconButton(onClick = onCollapse, modifier = Modifier.align(Alignment.Start)) {
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Collapse")
        }

        Spacer(Modifier.height(24.dp))

        AsyncImage(
            model = state.currentArtworkUrl,
            contentDescription = state.currentTitle,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(20.dp))
        )

        Spacer(Modifier.height(32.dp))

        Text(state.currentTitle, style = MaterialTheme.typography.headlineSmall)
        Text(
            state.currentArtist,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(24.dp))

        val progress = if (state.durationMs > 0) {
            if (isUserSeeking) sliderPosition else state.positionMs / state.durationMs.toFloat()
        } else 0f

        Slider(
            value = progress.coerceIn(0f, 1f),
            onValueChange = { isUserSeeking = true; sliderPosition = it },
            onValueChangeFinished = {
                isUserSeeking = false
                viewModel.seekTo((sliderPosition * state.durationMs).toLong())
            },
            modifier = Modifier.fillMaxWidth()
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatMs(state.positionMs), style = MaterialTheme.typography.labelSmall)
            Text(formatMs(state.durationMs), style = MaterialTheme.typography.labelSmall)
        }

        Spacer(Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { /* toggle shuffle in ViewModel */ }) {
                Icon(Icons.Default.Shuffle, contentDescription = "Shuffle")
            }
            IconButton(onClick = viewModel::skipPrevious) {
                Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
            }
            FilledIconButton(onClick = viewModel::togglePlayPause, modifier = Modifier.size(64.dp)) {
                Icon(
                    imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (state.isPlaying) "Pause" else "Play",
                    modifier = Modifier.size(32.dp)
                )
            }
            IconButton(onClick = viewModel::skipNext) {
                Icon(Icons.Default.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = { /* toggle repeat in ViewModel */ }) {
                Icon(Icons.Default.Repeat, contentDescription = "Repeat")
            }
        }

        state.errorMessage?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.weight(1f))

        // Queue list — tapping a row jumps straight to that track.
        if (state.queue.isNotEmpty()) {
            Text("Up next", style = MaterialTheme.typography.titleSmall, modifier = Modifier.align(Alignment.Start))
            QueueList(
                queue = state.queue,
                currentIndex = state.currentQueueIndex,
                onTrackClick = { index -> viewModel.playFromQueue(index) }
            )
        }
    }
}

@Composable
private fun QueueList(
    queue: List<com.streamtune.music.data.remote.SearchResult>,
    currentIndex: Int,
    onTrackClick: (Int) -> Unit
) {
    androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
        androidx.compose.foundation.lazy.itemsIndexed(queue, key = { _, item -> item.videoId }) { index, track ->
            val isCurrent = index == currentIndex
            ListItem(
                headlineContent = {
                    Text(
                        track.title, maxLines = 1,
                        color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                },
                supportingContent = { Text(track.artist, maxLines = 1) },
                trailingContent = {
                    if (isCurrent) Icon(Icons.Default.Equalizer, contentDescription = "Now playing", tint = MaterialTheme.colorScheme.primary)
                },
                modifier = Modifier.clickable { onTrackClick(index) }
            )
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0))
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
