package com.streamtune.music.ui.downloads

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.streamtune.music.data.download.DownloadedTrack
import com.streamtune.music.data.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val repository: MusicRepository
) : ViewModel() {

    val downloads: StateFlow<List<DownloadedTrack>> = repository.observeDownloads()

    fun removeDownload(videoId: String) = repository.removeDownload(videoId)

    fun downloadTrack(track: com.streamtune.music.data.remote.SearchResult, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch { onResult(repository.downloadTrack(track)) }
    }
}
