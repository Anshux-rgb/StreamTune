package com.streamtune.music.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.streamtune.music.data.remote.SearchResult
import com.streamtune.music.data.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val isLoading: Boolean = true,
    val trending: List<SearchResult> = emptyList(),
    val quickPicks: List<SearchResult> = emptyList(),
    val recent: List<SearchResult> = emptyList(),
    val searchQuery: String = "",
    val searchResults: List<SearchResult> = emptyList(),
    val isSearching: Boolean = false,
    val downloadedVideoIds: Set<String> = emptySet(),
    val errorMessage: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: MusicRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadHomeFeed()
        observeHistory()
        observeDownloads()
    }

    private fun observeDownloads() {
        viewModelScope.launch {
            repository.observeDownloads().collect { downloads ->
                _uiState.value = _uiState.value.copy(
                    downloadedVideoIds = downloads.filter { it.isComplete }.map { it.videoId }.toSet()
                )
            }
        }
    }

    private fun loadHomeFeed() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val shelves = repository.getHomeFeed().getOrElse {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Couldn't reach the network — pull to refresh."
                )
                return@launch
            }
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                trending = shelves.firstOrNull { it.title.contains("Trending", ignoreCase = true) }?.items.orEmpty(),
                quickPicks = shelves.firstOrNull { it.title.contains("Quick", ignoreCase = true) }?.items.orEmpty()
            )
        }
    }

    private fun observeHistory() {
        viewModelScope.launch {
            repository.observeHistory().collect { history ->
                _uiState.value = _uiState.value.copy(
                    recent = history.map { SearchResult(it.videoId, it.title, it.artist, it.thumbnailUrl) }
                )
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        if (query.isBlank()) {
            _uiState.value = _uiState.value.copy(searchResults = emptyList(), isSearching = false)
            return
        }
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSearching = true)
            val results = repository.search(query).getOrElse {
                _uiState.value = _uiState.value.copy(isSearching = false, errorMessage = "Search failed — try again.")
                return@launch
            }
            // Guard against a slow, stale response overwriting a newer query's results.
            if (_uiState.value.searchQuery == query) {
                _uiState.value = _uiState.value.copy(searchResults = results, isSearching = false)
            }
        }
    }

    fun toggleFavorite(track: SearchResult) {
        viewModelScope.launch { repository.toggleFavorite(track) }
    }

    fun downloadTrack(track: SearchResult) {
        viewModelScope.launch { repository.downloadTrack(track) }
    }
}
