package com.streamtune.music.ui.player

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.streamtune.music.data.remote.SearchResult
import com.streamtune.music.data.repository.MusicRepository
import com.streamtune.music.service.PlaybackService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PlaybackUiState(
    val currentTitle: String = "",
    val currentArtist: String = "",
    val currentArtworkUrl: String = "",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isBuffering: Boolean = false,
    val queue: List<SearchResult> = emptyList(),
    val currentQueueIndex: Int = 0,
    val errorMessage: String? = null
)

/**
 * Bridges the Compose UI to the playback service via a MediaController — the
 * standard Media3 pattern. The ViewModel never touches ExoPlayer directly;
 * it only ever talks through the controller, exactly like a remote control
 * app would (e.g. Android Auto), which keeps UI and playback state naturally
 * in sync regardless of which screen is on top.
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: MusicRepository
) : ViewModel() {

    private var controller: MediaController? = null

    private val _uiState = MutableStateFlow(PlaybackUiState())
    val uiState: StateFlow<PlaybackUiState> = _uiState.asStateFlow()

    init {
        connectController()
    }

    private fun connectController() {
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get().also { attachListener(it) }
        }, MoreExecutors.directExecutor())
    }

    private fun attachListener(controller: MediaController) {
        controller.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
            }

            override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
                _uiState.value = _uiState.value.copy(
                    currentTitle = mediaMetadata.title?.toString().orEmpty(),
                    currentArtist = mediaMetadata.artist?.toString().orEmpty(),
                    currentArtworkUrl = mediaMetadata.artworkUri?.toString().orEmpty()
                )
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // Fires on skip-next/previous, auto-advance, and queue-jump alike,
                // so this one callback keeps "now playing" highlighted correctly
                // in the queue list regardless of how the track changed.
                _uiState.value = _uiState.value.copy(currentQueueIndex = controller.currentMediaItemIndex)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _uiState.value = _uiState.value.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    durationMs = controller.duration.coerceAtLeast(0)
                )
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                // Covers socket disconnects / unreachable host mid-stream —
                // surface a message instead of leaving the UI stuck buffering.
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Playback error: ${error.errorCodeName}",
                    isBuffering = false
                )
            }
        })
    }

    /** Convenience for a single tapped track — wraps it as a one-item queue. */
    fun playTrack(track: SearchResult) = playQueue(listOf(track), startIndex = 0)

    /**
     * Resolves an entire queue's stream URLs up front (in parallel) and hands
     * the whole thing to the controller in one call, so skip-next/previous
     * are instant instead of triggering a fresh network fetch each time.
     * [startIndex] is the track the user actually tapped within [tracks]
     * (e.g. the row they clicked in a carousel) — everything before it in
     * the list still loads into the queue as "previous" tracks.
     */
    fun playQueue(tracks: List<SearchResult>, startIndex: Int) {
        if (tracks.isEmpty()) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBuffering = true, errorMessage = null)
            val prepared = repository.prepareQueue(tracks, startIndex)

            if (prepared.items.isEmpty()) {
                _uiState.value = _uiState.value.copy(
                    isBuffering = false,
                    errorMessage = "Couldn't load any of those tracks — check your connection and try again."
                )
                return@launch
            }

            val mediaItems: List<MediaItem> = prepared.items.map { (track, stream) ->
                PlaybackService.buildMediaItem(
                    videoId = track.videoId,
                    title = track.title,
                    artist = track.artist,
                    artworkUri = track.thumbnailUrl,
                    streamUrl = stream.streamUrl
                )
            }

            controller?.apply {
                setMediaItems(mediaItems, prepared.startIndex, /* startPositionMs = */ 0L)
                prepare()
                play()
            }

            _uiState.value = _uiState.value.copy(
                queue = prepared.items.map { it.first },
                errorMessage = if (prepared.droppedCount > 0) {
                    "${prepared.droppedCount} track(s) in that list couldn't be loaded and were skipped."
                } else null
            )
        }
    }

    fun togglePlayPause() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun skipNext() = controller?.seekToNextMediaItem()
    fun skipPrevious() = controller?.seekToPreviousMediaItem()
    fun seekTo(positionMs: Long) = controller?.seekTo(positionMs)

    /** Jumps straight to a specific position in the already-loaded queue (tapping a row in the queue list). */
    fun playFromQueue(index: Int) = controller?.seekTo(index, /* positionMs = */ 0L)

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
