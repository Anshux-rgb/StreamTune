package com.streamtune.music.data.local

import androidx.room.*

@Entity(tableName = "favorites")
data class FavoriteSongEntity(
    @PrimaryKey val videoId: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String,
    val addedAtEpochMs: Long
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAtEpochMs: Long
)

@Entity(
    tableName = "playlist_songs",
    primaryKeys = ["playlistId", "videoId"]
)
data class PlaylistSongCrossRef(
    val playlistId: Long,
    val videoId: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String,
    val position: Int
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoId: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String,
    val playedAtEpochMs: Long
)

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY addedAtEpochMs DESC")
    fun observeAll(): kotlinx.coroutines.flow.Flow<List<FavoriteSongEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE videoId = :videoId)")
    suspend fun isFavorite(videoId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(song: FavoriteSongEntity)

    @Query("DELETE FROM favorites WHERE videoId = :videoId")
    suspend fun remove(videoId: String)
}

@Dao
interface PlaylistDao {
    @Insert
    suspend fun createPlaylist(playlist: PlaylistEntity): Long

    @Query("SELECT * FROM playlists ORDER BY createdAtEpochMs DESC")
    fun observePlaylists(): kotlinx.coroutines.flow.Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addSongToPlaylist(crossRef: PlaylistSongCrossRef)

    @Query("SELECT * FROM playlist_songs WHERE playlistId = :playlistId ORDER BY position ASC")
    fun observeSongsInPlaylist(playlistId: Long): kotlinx.coroutines.flow.Flow<List<PlaylistSongCrossRef>>
}

@Dao
interface HistoryDao {
    @Insert
    suspend fun record(entry: HistoryEntity)

    @Query("SELECT * FROM history ORDER BY playedAtEpochMs DESC LIMIT 50")
    fun observeRecent(): kotlinx.coroutines.flow.Flow<List<HistoryEntity>>

    @Query("DELETE FROM history")
    suspend fun clear()
}

@Database(
    entities = [
        FavoriteSongEntity::class,
        PlaylistEntity::class,
        PlaylistSongCrossRef::class,
        HistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun historyDao(): HistoryDao
}
