package com.streamtune.music

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class StreamTuneApp : Application()
