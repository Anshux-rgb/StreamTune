package com.streamtune.music.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.streamtune.music.data.remote.SearchResult

/**
 * @param onQueueSelected Called with (the full shelf/result list the user was
 * browsing, index tapped) so the player can queue up the rest of that shelf —
 * e.g. tapping track 3 in "Trending" queues tracks 3, 4, 5... to play next,
 * matching how YT Music / Spotify carousels behave.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onQueueSelected: (tracks: List<SearchResult>, startIndex: Int) -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        SearchBar(
            query = state.searchQuery,
            onQueryChange = viewModel::onSearchQueryChanged
        )

        if (state.searchQuery.isNotBlank()) {
            // Search results take over the screen while a query is active.
            SearchResultsList(
                results = state.searchResults,
                isSearching = state.isSearching,
                downloadedVideoIds = state.downloadedVideoIds,
                onTrackClick = { track ->
                    onQueueSelected(state.searchResults, state.searchResults.indexOf(track))
                },
                onDownloadClick = viewModel::downloadTrack
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                if (state.recent.isNotEmpty()) {
                    item { TrackCarousel("Recent", state.recent, onQueueSelected) }
                }
                item { TrackCarousel("Quick Picks", state.quickPicks, onQueueSelected) }
                item { TrackCarousel("Trending", state.trending, onQueueSelected) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchBar(query: String, onQueryChange: (String) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { Text("Search songs, artists, albums") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        singleLine = true,
        shape = RoundedCornerShape(28.dp)
    )
}

@Composable
private fun TrackCarousel(
    title: String,
    items: List<SearchResult>,
    onQueueSelected: (tracks: List<SearchResult>, startIndex: Int) -> Unit
) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        if (items.isEmpty()) {
            Text(
                "Nothing here yet",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(items, key = { _, it -> it.videoId }) { index, track ->
                    TrackCard(track) { onQueueSelected(items, index) }
                }
            }
        }
    }
}

@Composable
private fun TrackCard(track: SearchResult, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(140.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = track.thumbnailUrl,
            contentDescription = track.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.height(6.dp))
        Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
        Text(
            track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SearchResultsList(
    results: List<SearchResult>,
    isSearching: Boolean,
    downloadedVideoIds: Set<String>,
    onTrackClick: (SearchResult) -> Unit,
    onDownloadClick: (SearchResult) -> Unit
) {
    if (isSearching && results.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    LazyColumn {
        items(results, key = { it.videoId }) { track ->
            val isDownloaded = track.videoId in downloadedVideoIds
            ListItem(
                headlineContent = { Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingContent = {
                    AsyncImage(
                        model = track.thumbnailUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(48.dp).clip(RoundedCornerShape(6.dp))
                    )
                },
                trailingContent = {
                    IconButton(onClick = { if (!isDownloaded) onDownloadClick(track) }, enabled = !isDownloaded) {
                        Icon(
                            imageVector = if (isDownloaded) Icons.Default.DownloadDone else Icons.Default.Download,
                            contentDescription = if (isDownloaded) "Downloaded" else "Download for offline listening",
                            tint = if (isDownloaded) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                },
                modifier = Modifier.clickable { onTrackClick(track) }
            )
        }
    }
}
