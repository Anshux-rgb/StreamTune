package com.streamtune.music.ui.downloads

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DownloadForOffline
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.exoplayer.offline.Download
import coil.compose.AsyncImage
import com.streamtune.music.data.download.DownloadedTrack
import com.streamtune.music.data.remote.SearchResult

@Composable
fun DownloadsScreen(
    onQueueSelected: (tracks: List<SearchResult>, startIndex: Int) -> Unit,
    viewModel: DownloadsViewModel = hiltViewModel()
) {
    val downloads by viewModel.downloads.collectAsState()

    if (downloads.isEmpty()) {
        EmptyDownloads()
        return
    }

    val completedTracks = downloads.filter { it.isComplete }.map { it.asSearchResult() }

    LazyColumn {
        itemsIndexed(downloads, key = { _, it -> it.videoId }) { _, item ->
            DownloadRow(
                item = item,
                onClick = {
                    if (item.isComplete) {
                        val index = completedTracks.indexOfFirst { it.videoId == item.videoId }
                        onQueueSelected(completedTracks, index.coerceAtLeast(0))
                    }
                },
                onRemove = { viewModel.removeDownload(item.videoId) }
            )
        }
    }
}

@Composable
private fun DownloadRow(item: DownloadedTrack, onClick: () -> Unit, onRemove: () -> Unit) {
    ListItem(
        headlineContent = { Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = {
            Column {
                Text(item.artist, maxLines = 1, overflow = TextOverflow.Ellipsis)
                when (item.state) {
                    Download.STATE_DOWNLOADING -> LinearProgressIndicator(
                        progress = { (item.progressPercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    )
                    Download.STATE_QUEUED -> Text("Queued…", style = MaterialTheme.typography.labelSmall)
                    Download.STATE_FAILED -> Text(
                        "Download failed", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                    else -> {}
                }
            }
        },
        leadingContent = {
            AsyncImage(
                model = item.thumbnailUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(6.dp))
            )
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (item.isComplete) Icons.Default.CloudDone else Icons.Default.CloudOff,
                    contentDescription = if (item.isComplete) "Available offline" else "Not yet downloaded",
                    tint = if (item.isComplete) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove download")
                }
            }
        },
        modifier = Modifier.clickable(enabled = item.isComplete, onClick = onClick)
    )
}

@Composable
private fun EmptyDownloads() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.DownloadForOffline,
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "No downloads yet — tap the download icon on any track to save it for offline listening.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
