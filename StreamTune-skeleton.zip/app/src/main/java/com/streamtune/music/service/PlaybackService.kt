package com.streamtune.music.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.streamtune.music.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * The single background component responsible for actual audio playback.
 *
 * Why MediaSessionService (not a plain Service): it gives us, for free —
 *  - a MediaSession the OS, lock screen, Bluetooth headset, Android Auto,
 *    and Wear OS can all discover and control
 *  - the system media notification (play/pause/skip) wired to that session
 *  - correct foreground-service lifecycle tied to actual playback state
 *
 * ExoPlayer is configured with `setAudioAttributes(..., handleAudioFocus =
 * true)`, which makes Media3 automatically:
 *  - pause playback when a phone call comes in or another app takes audio focus
 *  - duck volume for transient focus loss (e.g. a notification sound)
 *  - resume automatically once focus is returned, if it was auto-paused
 */
@AndroidEntryPoint
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    @Inject
    lateinit var cacheDataSourceFactory: CacheDataSource.Factory

    override fun onCreate() {
        super.onCreate()

        // cacheDataSourceFactory (from DownloadModule) checks the on-disk
        // download cache before the network. A fully downloaded track (see
        // DownloadRepository) is served entirely from disk and never touches
        // the network; anything not cached falls through to normal streaming
        // exactly as before. Both downloads and playback are keyed by video
        // ID (customCacheKey), not the ephemeral signed URL, so this keeps
        // working after that URL expires.
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(cacheDataSourceFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            // Keep the player (and thus the foreground service) alive briefly
            // after playback ends, matching how Spotify/YT Music behave.
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && !player.hasNextMediaItem()) {
                    // Nothing left in the queue — let the service decide whether
                    // to stop itself (see onTaskRemoved) rather than looping forever.
                }
            }
        })

        // Tapping the notification reopens the app at the full player.
        val sessionActivityIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                putExtra(EXTRA_OPEN_PLAYER, true)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityIntent)
            .setCallback(PlaybackCallback())
            .build()
    }

    /** Lets MediaController clients (our Compose UI, Android Auto, etc.) attach. */
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    /**
     * If the user swipes the app away from Recents while nothing is actively
     * playing, stop the foreground service instead of lingering silently.
     * If music IS playing, Media3 keeps it alive — matching Spotify/YT Music.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player ?: return
        if (!player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }

    /** Minimal callback — extend here for custom commands (e.g. "toggle favorite" from the notification). */
    private inner class PlaybackCallback : MediaSession.Callback

    companion object {
        const val EXTRA_OPEN_PLAYER = "open_player"

        /** Helper the repository/ViewModel layer uses to build a playable item once it has a resolved stream URL. */
        fun buildMediaItem(videoId: String, title: String, artist: String, artworkUri: String, streamUrl: String): MediaItem =
            MediaItem.Builder()
                .setMediaId(videoId)
                .setUri(streamUrl)
                .setCustomCacheKey(videoId) // stable key shared with DownloadRepository's DownloadRequest
                .setMediaMetadata(
                    androidx.media3.common.MediaMetadata.Builder()
                        .setTitle(title)
                        .setArtist(artist)
                        .setArtworkUri(android.net.Uri.parse(artworkUri))
                        .build()
                )
                .build()
    }
}
