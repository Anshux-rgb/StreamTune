package com.streamtune.music.data.download

import android.content.Context
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import com.streamtune.music.data.remote.MusicExtractor
import com.streamtune.music.data.remote.SearchResult
import com.streamtune.music.service.MusicDownloadService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * IMPORTANT — why this exists as its own layer instead of just calling
 * MusicExtractor.getStreamUrl() again at playback time:
 *
 * The audio URLs InnerTube hands back are signed and time-limited (they
 * expire after a few hours). If we cached content keyed by that URL, a
 * "downloaded" song would silently stop playing offline once its original
 * URL expired — even though the bytes are still sitting on disk. Media3's
 * fix for exactly this problem is [DownloadRequest.customCacheKey]: both the
 * download AND later playback are keyed by a stable ID (we use the YouTube
 * video ID) instead of the ephemeral URL, so cache lookups keep working
 * indefinitely. [com.streamtune.music.service.PlaybackService] and this
 * class must agree on that key — see [PLAYABLE_CACHE_KEY].
 */
@Singleton
class DownloadRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val downloadManager: DownloadManager,
    private val extractor: MusicExtractor
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _downloads = MutableStateFlow<List<DownloadedTrack>> (emptyList())
    val downloads: StateFlow<List<DownloadedTrack>> = _downloads.asStateFlow()

    init {
        // Seed with whatever was already downloaded before this process started...
        refreshFromIndex()
        // ...then keep listening for progress/state changes as they happen.
        // DownloadManager fires these on its own internal handler thread, but
        // we hop to IO before touching the (SQLite-backed) DownloadIndex regardless.
        downloadManager.addListener(object : DownloadManager.Listener {
            override fun onDownloadChanged(dm: DownloadManager, download: Download, finalException: Exception?) {
                refreshFromIndex()
            }
            override fun onDownloadRemoved(dm: DownloadManager, download: Download) {
                refreshFromIndex()
            }
        })
    }

    private fun refreshFromIndex() {
        scope.launch {
            val result = mutableListOf<DownloadedTrack>()
            runCatching {
                downloadManager.downloadIndex.getDownloads().use { cursor ->
                    while (cursor.moveToNext()) {
                        val download = cursor.download
                        val metadata = runCatching {
                            json.decodeFromString<DownloadMetadata>(String(download.request.data))
                        }.getOrNull() ?: continue
                        result += DownloadedTrack(
                            videoId = download.request.id,
                            title = metadata.title,
                            artist = metadata.artist,
                            thumbnailUrl = metadata.thumbnailUrl,
                            state = download.state,
                            progressPercent = download.percentDownloaded
                        )
                    }
                }
            }
            _downloads.value = result
        }
    }

    /** True only once bytes are fully on disk — the safe point to skip the network entirely at playback time. */
    fun isFullyDownloaded(videoId: String): Boolean =
        runCatching { downloadManager.downloadIndex.getDownload(videoId)?.state == Download.STATE_COMPLETED }
            .getOrDefault(false)

    /**
     * Resolves a fresh (short-lived) stream URL, then queues the download
     * keyed by [track]'s video ID so it survives that URL's later expiry.
     * Returns false if the stream couldn't be resolved (e.g. offline already).
     */
    suspend fun downloadTrack(track: SearchResult): Boolean = withContext(Dispatchers.IO) {
        val stream = runCatching { extractor.getStreamUrl(track.videoId) }.getOrNull() ?: return@withContext false

        val metadataBytes = json.encodeToString(
            DownloadMetadata(title = track.title, artist = track.artist, thumbnailUrl = track.thumbnailUrl)
        ).toByteArray()

        val request = DownloadRequest.Builder(track.videoId, android.net.Uri.parse(stream.streamUrl))
            .setCustomCacheKey(track.videoId) // <-- the stable key described above
            .setMimeType(if (stream.mimeType.contains("webm")) MimeTypes.AUDIO_WEBM else MimeTypes.AUDIO_MP4)
            .setData(metadataBytes)
            .build()

        DownloadService.sendAddDownload(context, MusicDownloadService::class.java, request, /* foreground = */ false)
        true
    }

    fun removeDownload(videoId: String) {
        DownloadService.sendRemoveDownload(context, MusicDownloadService::class.java, videoId, /* foreground = */ false)
    }

    fun pauseAll() = DownloadService.sendPauseDownloads(context, MusicDownloadService::class.java, false)
    fun resumeAll() = DownloadService.sendResumeDownloads(context, MusicDownloadService::class.java, false)
}

@Serializable
data class DownloadMetadata(val title: String, val artist: String, val thumbnailUrl: String)

data class DownloadedTrack(
    val videoId: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String,
    val state: Int, // Download.STATE_* — QUEUED / DOWNLOADING / COMPLETED / FAILED / REMOVING / STOPPED
    val progressPercent: Float
) {
    fun asSearchResult() = SearchResult(videoId, title, artist, thumbnailUrl)
    val isComplete get() = state == Download.STATE_COMPLETED
    val isFailed get() = state == Download.STATE_FAILED
}
