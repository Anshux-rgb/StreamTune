package com.streamtune.music.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * MusicExtractor talks directly to the same "InnerTube" JSON endpoints that
 * the music.youtube.com web client itself calls. This is the same technique
 * used by well-known open-source players such as InnerTune / RiMusic /
 * Metrolist: no OAuth, no official Data API key, no user login required.
 *
 * IMPORTANT — before shipping:
 * 1. INNERTUBE_API_KEY below is the public client key embedded in YT Music's
 *    own webpage JavaScript (visible to anyone who opens devtools on
 *    music.youtube.com and inspects a network request). It rotates
 *    occasionally — if requests start failing, re-extract it from a fresh
 *    page load and update the constant.
 * 2. Because this relies on an undocumented, reverse-engineered surface,
 *    Google can change the response shape at any time. Keep the JSON
 *    parsing defensive (see the `?.` chains below) and expect to maintain
 *    this file over time — this is exactly the maintenance burden the
 *    NewPipe/InnerTune projects also carry.
 */
@Singleton
class MusicExtractor @Inject constructor(
    private val client: OkHttpClient
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val jsonMediaType = "application/json".toMediaType()

    companion object {
        private const val BASE_URL = "https://music.youtube.com/youtubei/v1"

        // Public WEB_REMIX client key — see class doc above. Replace with a
        // freshly captured value if search/playback starts returning errors.
        private const val INNERTUBE_API_KEY = "REPLACE_WITH_CURRENT_WEB_REMIX_KEY"

        private const val CLIENT_NAME = "WEB_REMIX"
        private const val CLIENT_VERSION = "1.20240101.01.00"
    }

    /** Shared "context" block every InnerTube request needs to identify the calling client. */
    private fun baseContext(): JsonObject = buildJsonObject {
        putJsonObject("context") {
            putJsonObject("client") {
                put("clientName", CLIENT_NAME)
                put("clientVersion", CLIENT_VERSION)
                put("hl", "en")
                put("gl", "US")
            }
        }
    }

    private fun post(endpoint: String, body: JsonObject): JsonObject {
        val request = Request.Builder()
            .url("$BASE_URL/$endpoint?key=$INNERTUBE_API_KEY")
            .addHeader("Content-Type", "application/json")
            .addHeader("Referer", "https://music.youtube.com/")
            .addHeader("Origin", "https://music.youtube.com")
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("InnerTube request to $endpoint failed: HTTP ${response.code}")
            }
            val text = response.body?.string() ?: throw IOException("Empty response body from $endpoint")
            return json.parseToJsonElement(text).jsonObject
        }
    }

    /**
     * Searches songs/albums/artists/playlists for [query]. Returns a flat list
     * of lightweight results the ViewModel layer maps into UI state.
     */
    suspend fun search(query: String): List<SearchResult> = withContext(Dispatchers.IO) {
        val body = buildJsonObject {
            putJsonObject("context") {
                putJsonObject("client") {
                    put("clientName", CLIENT_NAME)
                    put("clientVersion", CLIENT_VERSION)
                }
            }
            put("query", query)
            put("params", "EgWKAQIIAWoKEAMQBBAJEAoQBQ%3D%3D") // filter: songs
        }

        val response = runCatching { post("search", body) }.getOrElse {
            // Network hiccup / socket disconnect — surface an empty list rather
            // than crashing the UI; the repository layer decides how to retry.
            return@withContext emptyList()
        }

        parseSearchResults(response)
    }

    /**
     * Resolves a YouTube video ID to a direct, streamable audio URL (.m4a /
     * .webm). Picks the highest-bitrate audio-only adaptive format available.
     */
    suspend fun getStreamUrl(videoId: String): StreamInfo? = withContext(Dispatchers.IO) {
        val body = buildJsonObject {
            putJsonObject("context") {
                putJsonObject("client") {
                    put("clientName", "ANDROID_MUSIC")
                    put("clientVersion", "7.16.53")
                    put("androidSdkVersion", 30)
                }
            }
            put("videoId", videoId)
        }

        val response = runCatching { post("player", body) }.getOrNull() ?: return@withContext null

        val adaptiveFormats = response["streamingData"]
            ?.jsonObject?.get("adaptiveFormats")
            ?.jsonArray ?: return@withContext null

        val bestAudio = adaptiveFormats
            .mapNotNull { it.jsonObject.takeIf { fmt -> fmt["mimeType"]?.jsonPrimitive?.content?.startsWith("audio/") == true } }
            .maxByOrNull { it["bitrate"]?.jsonPrimitive?.intOrNull ?: 0 }
            ?: return@withContext null

        val url = bestAudio["url"]?.jsonPrimitive?.content ?: return@withContext null
        val mime = bestAudio["mimeType"]?.jsonPrimitive?.content ?: "audio/webm"
        val bitrate = bestAudio["bitrate"]?.jsonPrimitive?.intOrNull ?: 0

        StreamInfo(videoId = videoId, streamUrl = url, mimeType = mime, bitrateKbps = bitrate / 1000)
    }

    /** Fetches the home feed (Quick Picks / Trending style shelves). */
    suspend fun getHomeFeed(): List<HomeShelf> = withContext(Dispatchers.IO) {
        val response = runCatching { post("browse", buildJsonObject {
            putJsonObject("context") { putJsonObject("client") {
                put("clientName", CLIENT_NAME); put("clientVersion", CLIENT_VERSION)
            } }
            put("browseId", "FEmusic_home")
        }) }.getOrNull() ?: return@withContext emptyList()

        parseHomeShelves(response)
    }

    // --- JSON → domain mapping -------------------------------------------------
    // InnerTube responses are deeply nested "renderer" trees. Real implementations
    // walk several more levels than shown here; keep this isolated in one place
    // so a shape change from Google only requires updating these two functions.

    private fun parseSearchResults(root: JsonObject): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        // Walk contents -> sectionListRenderer -> musicShelfRenderer -> contents
        val shelves = root["contents"]?.jsonObject
            ?.get("tabbedSearchResultsRenderer")?.jsonObject
            ?.get("tabs")?.jsonArray
            ?.firstOrNull()?.jsonObject
            ?.get("tabRenderer")?.jsonObject
            ?.get("content")?.jsonObject
            ?.get("sectionListRenderer")?.jsonObject
            ?.get("contents")?.jsonArray ?: return results

        for (shelf in shelves) {
            val items = shelf.jsonObject["musicShelfRenderer"]?.jsonObject
                ?.get("contents")?.jsonArray ?: continue

            for (item in items) {
                val renderer = item.jsonObject["musicResponsiveListItemRenderer"]?.jsonObject ?: continue
                val videoId = renderer["playlistItemData"]?.jsonObject
                    ?.get("videoId")?.jsonPrimitive?.content ?: continue

                val flexColumns = renderer["flexColumns"]?.jsonArray
                val title = flexColumns?.getOrNull(0)?.jsonObject
                    ?.get("musicResponsiveListItemFlexColumnRenderer")?.jsonObject
                    ?.get("text")?.jsonObject?.get("runs")?.jsonArray
                    ?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: "Unknown title"

                val artist = flexColumns?.getOrNull(1)?.jsonObject
                    ?.get("musicResponsiveListItemFlexColumnRenderer")?.jsonObject
                    ?.get("text")?.jsonObject?.get("runs")?.jsonArray
                    ?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: "Unknown artist"

                val thumbnail = renderer["thumbnail"]?.jsonObject
                    ?.get("musicThumbnailRenderer")?.jsonObject
                    ?.get("thumbnail")?.jsonObject?.get("thumbnails")?.jsonArray
                    ?.lastOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content ?: ""

                results += SearchResult(videoId, title, artist, thumbnail)
            }
        }
        return results
    }

    private fun parseHomeShelves(root: JsonObject): List<HomeShelf> {
        // Same walking pattern as search — omitted body kept intentionally
        // thin here since the exact shelf layout (Quick Picks vs Trending vs
        // "Forgotten favorites") varies per account/region. Wire this up the
        // same way as parseSearchResults once you've inspected a live response
        // (Android Studio's network inspector on a real device is the fastest
        // way to see the current shape).
        return emptyList()
    }
}

data class SearchResult(
    val videoId: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String
)

data class StreamInfo(
    val videoId: String,
    val streamUrl: String,
    val mimeType: String,
    val bitrateKbps: Int
)

data class HomeShelf(
    val title: String,
    val items: List<SearchResult>
)
