# StreamTune — Setup Guide

A skeleton for a Kotlin + Jetpack Compose YouTube-Music-style player, built
the same way open-source players like InnerTune / RiMusic / Metrolist are:
no official Data API key, no forced Google login — audio is streamed by
talking directly to the public InnerTube JSON endpoints music.youtube.com's
own web client calls.

## 1. Project setup

1. Create a new **Empty Activity** project in Android Studio (Kotlin, min SDK 24).
2. Replace `gradle/libs.versions.toml` and `app/build.gradle.kts` with the
   versions in this bundle.
3. Enable version catalogs if prompted, sync Gradle.
4. Copy `AndroidManifest.xml` over yours, keeping your existing `<application>`
   icon/label references.
5. Drop the `com/streamtune/music/...` package tree into
   `app/src/main/java/`.

## 2. Fill in the one placeholder

`data/remote/MusicExtractor.kt` has:

```kotlin
private const val INNERTUBE_API_KEY = "REPLACE_WITH_CURRENT_WEB_REMIX_KEY"
```

Open `music.youtube.com` in a desktop browser with devtools open, run any
search, and inspect the `POST` request to `/youtubei/v1/search?key=...` — copy
the `key` query-param value. It's a public client identifier (not a per-user
secret) but Google rotates it occasionally; if search suddenly starts
returning HTTP errors, re-capture it the same way.

## 3. How the pieces fit together (Clean Architecture / MVVM)

```
ui/ (Compose + ViewModel, StateFlow)
   ├─ home/HomeScreen.kt + HomeViewModel.kt      — search, carousels
   ├─ player/PlayerScreen.kt + PlayerViewModel.kt — full player, talks to PlaybackService via MediaController
   └─ components/MiniPlayer.kt                   — persistent bottom bar

data/ (Model layer)
   ├─ remote/MusicExtractor.kt   — InnerTube search + stream-URL resolution
   ├─ local/Entities.kt          — Room: favorites, playlists, history
   └─ repository/MusicRepository.kt — single source of truth for ViewModels

service/PlaybackService.kt — MediaSessionService + ExoPlayer, runs
                              independently of any Activity's lifecycle

di/AppModule.kt — Hilt bindings for OkHttp, Room, Media3 DataSource
```

The ViewModel layer **never** touches ExoPlayer directly — it only ever
talks to `PlaybackService` through a `MediaController`, exactly like an
Android Auto head unit would. That's what keeps the lock-screen controls,
the mini-player, and the full player screen all in sync automatically.

## 4. Audio focus & background playback — already wired up

`PlaybackService.onCreate()` builds the `ExoPlayer` with:

```kotlin
.setAudioAttributes(AudioAttributes.Builder()...build(), /* handleAudioFocus = */ true)
```

That single flag makes Media3 automatically pause on an incoming call,
duck for transient interruptions (like a notification ping), and resume
when focus returns — no manual `AudioManager` juggling required.

## 5. Offline downloads

Tap the download icon on a search result (or a row in **Downloads**) and the
track is fetched to disk via Media3's `DownloadManager`; a **Downloads** tab
lists progress and lets you remove tracks. Tapping a *completed* download
plays it — with **no network call at all** — even in airplane mode.

**The one subtlety that matters here:** InnerTube stream URLs are signed and
expire after a few hours. If downloads were cached by URL, a "downloaded"
song would quietly stop playing once that URL expired, even with the bytes
still on disk. The fix — and the reason for `data/download/DownloadRepository.kt`
existing as its own layer — is Media3's `customCacheKey`: both the
`DownloadRequest` (in `DownloadRepository.downloadTrack()`) and the `MediaItem`
built at playback time (in `PlaybackService.buildMediaItem()`) are keyed by the
stable YouTube video ID instead of the URL. `PlaybackService`'s ExoPlayer reads
through a `CacheDataSource` wrapping that same on-disk cache, so a fully
downloaded track is served from disk transparently — same code path as
streaming, just backed by a hit in the cache instead of a network fetch.

`MusicRepository.resolveStream()` goes one step further for the fully-offline
case: if `DownloadRepository.isFullyDownloaded()` is true, it skips the
network call to InnerTube entirely (which would otherwise time out with no
connectivity) and hands back a placeholder URL that's never actually fetched.

Rough edges here worth knowing about:
- `MusicDownloadService.getScheduler()` returns `null`, so an interrupted
  download does **not** auto-resume after the app process dies or the device
  reboots. Wiring a `WorkManagerScheduler` (plus `RECEIVE_BOOT_COMPLETED`) is
  the natural next step if you want that.
- The download cache is capped at 2 GB via `LeastRecentlyUsedCacheEvictor` in
  `DownloadModule.kt` — tune `MAX_CACHE_BYTES` or expose it as a settings
  screen.
- Download icons are wired into the Home search results list and Favorites;
  adding the same callback to the home carousels' `TrackCard` is a couple of
  lines if you want download buttons there too.

## 6. Known rough edges to finish before shipping

- **`parseHomeShelves()`** is stubbed — the home-feed JSON shape (Quick
  Picks vs. Trending vs. regional shelves) needs to be captured from a live
  response the same way you captured the API key, since it varies by
  account/region. `parseSearchResults()` shows the exact walking pattern to
  copy.
- **Shuffle/repeat buttons** in `PlayerScreen.kt` are stubbed — wire them to
  `controller.shuffleModeEnabled` / `controller.repeatMode`.
- **Offline resilience**: `MusicExtractor` already returns `null`/empty list
  on socket errors rather than crashing; add a Compose `SnackbarHost` fed by
  `uiState.errorMessage` in both ViewModels to surface that to the user.
- This entire approach depends on an undocumented API surface that Google
  can change without notice — budget ongoing maintenance time, same as any
  project built on NewPipeExtractor.

## 7. Legal note

Reverse-engineered InnerTube access sits outside YouTube's official Terms of
Service, which is why every app taking this approach (InnerTune, RiMusic,
Metrolist, NewPipe) distributes as open-source/side-load rather than through
the Play Store. Worth being upfront about that with anyone you share the APK
with.
